package tile;

import main.GamePanel;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TileManager {

    GamePanel gamePanel;
    Tile[] tile;
    int mapGrid1[][];


    public TileManager(GamePanel gamePanel){

        this.gamePanel=gamePanel;

        tile=new Tile[10];
        mapGrid1=new int[gamePanel.cols][gamePanel.rows];

        getTileImages();
        loadMap();
    }

    public void getTileImages(){

        try {
            tile[0]=new Tile();
            tile[0].image=ImageIO.read(getClass().getResourceAsStream("grass.png"));

            tile[1]=new Tile();
            tile[1].image= ImageIO.read(getClass().getResourceAsStream("stone.png"));

        }catch(IOException e){
            e.printStackTrace();
        }

    }

    public void loadMap(){
        try{
            InputStream input=getClass().getResourceAsStream("map1.txt");
            BufferedReader reader=new BufferedReader(new InputStreamReader(input));

            int col=0;
            int row=0;

            while(col< gamePanel.cols&&row< gamePanel.rows){
                String line=reader.readLine();

                while(col< gamePanel.cols) {
                    String numbers[] = line.split(" ");

                    int num = Integer.parseInt(numbers[col]);
                    mapGrid1[col][row] = num;
                    col++;
                }
                if (col==gamePanel.cols) {
                    col = 0;
                    row++;
                }
            }
        reader.close();

        }catch(Exception e){}

    }



    public void draw(Graphics2D g2){

        int col=0;
        int row=0;
        int x=0;
        int y=0;

        g2.drawImage(tile[0].image,x,y,gamePanel.tileSize,gamePanel.tileSize,null);
        while(col<gamePanel.cols&&row<gamePanel.rows){

            int tileNum=mapGrid1[col][row];

            g2.drawImage(tile[tileNum].image,x,y,gamePanel.tileSize,gamePanel.tileSize,null);
            col++;
            x+= gamePanel.tileSize;

            if (col==gamePanel.cols){
                col=0;
                x=0;
                row++;
                y+=gamePanel.tileSize;
            }
        }

    }
}
