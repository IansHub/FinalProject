package main;

import entity.Player;
import tile.TileManager;

import javax.swing.*;
import java.awt.*;

public class GamePanel extends JPanel implements Runnable{

    final int tile=16;
    final int scale=3;
    public final int tileSize=tile*scale;
    public final int cols=16;
    public final int rows=12;
    public final int screenWidth = tileSize*cols;
    public final int screenHeight=tileSize*rows;

    int eggX=100,eggY=100;
    int speed=5;
    int FPS=60;

    TileManager tileM=new TileManager(this);
    KeyHandler keyHandler = new KeyHandler();
    Thread gameThread;

    Player player = new Player(this,keyHandler);

    public GamePanel(){
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyHandler);
        this.setFocusable(true);
    }

    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void run(){
        double drawInterval=1000000000/FPS;
        double delta=0;
        long lastTime=System.nanoTime();
        long currentTime;
        while(gameThread!=null){
            currentTime=System.nanoTime();
            delta+=(currentTime-lastTime)/drawInterval;
            lastTime=currentTime;

            if(delta>=1){
                update();
                repaint();
                delta--;
                this.requestFocusInWindow();
            }
        }
        this.requestFocusInWindow();
    }

    public void update(){
        player.update();
    }

    public void paintComponent(Graphics g){

        super.paintComponent(g);
        Graphics2D g2=(Graphics2D) g;

        tileM.draw(g2);
        player.draw(g2);
        g2.dispose();

    }
}
