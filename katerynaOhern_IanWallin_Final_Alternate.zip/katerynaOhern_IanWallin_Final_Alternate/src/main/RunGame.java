package main;

import javax.swing.*;

public class RunGame {

    public static void main(String[] args) {

        JFrame gui = new JFrame();
        gui.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        gui.setTitle("Eggciting Adventure");
        gui.setVisible(true);

        GamePanel gamePanel = new GamePanel();
        gui.add(gamePanel);
        gui.pack();

        gamePanel.startGameThread();

    }
}
