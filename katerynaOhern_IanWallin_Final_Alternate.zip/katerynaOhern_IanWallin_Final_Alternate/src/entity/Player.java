package entity;

import main.GamePanel;
import main.KeyHandler;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;

public class Player extends Entity{

    GamePanel gamePanel;
    KeyHandler keyHandler;

    public Player(GamePanel gamePanel, KeyHandler keyHandler){

        this.gamePanel=gamePanel;
        this.keyHandler=keyHandler;

        playerDefaults();
        getEggGif();

    }
    public void playerDefaults(){
        x=300;
        y=300;
        speed=4;
    }
    public void getEggGif() {
        try {
            egg = ImageIO.read(getClass().getResource("egg.gif"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        public void update () {
            if (keyHandler.moveUp == true) {
                y -= speed;
            } else if (keyHandler.moveDown == true) {
                y += speed;
            } else if (keyHandler.moveLeft == true) {
                x -= speed;
            } else if (keyHandler.moveRight == true) {
                x += speed;
            }
        }
        public void draw (Graphics2D g2){
            BufferedImage image = egg;
            g2.drawImage(image, x, y, gamePanel.tileSize,gamePanel.tileSize,null);
        }
}


